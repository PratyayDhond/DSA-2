#include "graph.h"
#include<stdlib.h>
#include<stdio.h>
#include<limits.h>

void freeGraph(Graph *g, int index){
    if(!g)
        return;
    if(index == 0){
        free(g->arr);
        g->size = 0;
        return;
    }
// error here
    if(index > g->size)  index = g->size - 1;
    for(int i = index; i >= 0; i--){
        free(g->arr[i]);
    }
    free(g->arr);
    g->size = 0;
    return;
}

void initGraph(Graph * g, char * filename){
    FILE *fptr = fopen(filename, "r+");
    if(!fptr)
        return;
    int n = INT_MIN;
    int error = fscanf(fptr,"%d",&n);
    if(error == -1) // EMPTY FILE EOF reached
        return;
    g->size = n;
    g->arr = (int **) malloc(sizeof(int*) * g->size);
    if(!g->arr)
        return;

    for(int i = 0; i < n; i++){
        g->arr[i] = calloc(n,sizeof(int));
        if(!g->arr[i]){ // freeing previous allocated array
            freeGraph(g,i);
            return;
        }
    }
    int temp = INT_MIN;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            error = fscanf(fptr,"%d",&temp);
            g->arr[i][j] = temp;
            
                if(error == -1){
                    perror("aasf");
                    freeGraph(g,n);
                    return; // file contents ended abruptly
                }
        }
    }   
}

void displayGraph(Graph g){
    if(g.size == 0)
        return;
    for(int i = 0; i < g.size;i++){
        for(int j = 0; j < g.size; j++){
            printf("%d ",g.arr[i][j]);
        }
        printf("\n");
    }
}