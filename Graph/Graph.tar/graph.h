typedef struct Graph{
    int **arr;
    int size;
}Graph;

void initGraph(Graph *g, char * filename);
void displayGraph(Graph g);