#include<stdio.h>
#include "graph.h"

int main(){
    Graph g;
    initGraph(&g,"g1");
    displayGraph(g);
    return 0;
}