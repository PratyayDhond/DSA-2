
#ifndef NODESTRUCT
#define NODESTRUCT

typedef struct Node{
	int data;
	struct Node *left, *right;
}Node;

#endif

